package com.cristorey.androidchefs;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.util.Vector;


public class VerTodasRecetas extends Activity {
	ListView lv;
	TextView seleccionado;
	Bundle id_user;
	public final int MENU_ABOUT = 1;
	public final int MENU_DESCONECTAR = 2;
	long idUser;
	private Vector <String> recetas = new Vector<String>();
	private Vector <String> nombre = new Vector<String>();
	private Vector <String> ingrediente = new Vector<String>();
	private Vector <String> proceso = new Vector<String>();
	private Vector <Long> ids = new Vector<Long>();
	@Override
	public void onCreate(Bundle savedInstaceState){
		super.onCreate(savedInstaceState);
		setContentView(R.layout.ver_recetas);
		
		id_user = this.getIntent().getExtras();
		idUser = id_user.getLong("idUser");
		Cursor  c = mostrarRecetas(idUser);
		lv = (ListView)findViewById(R.id.list);
		seleccionado = (TextView)findViewById(R.id.seleccionado);
		final Intent intMostrarNuevaReceta = new Intent(VerTodasRecetas.this, VerUnaReceta.class);

		lv.setAdapter(new ArrayAdapter<String>(this,R.layout.list_item, recetas));
		while (c.moveToNext()) {
			ids.addElement(c.getLong(0));
			recetas.addElement(c.getString(2).toString());
			ingrediente.addElement(c.getString(3).toString());
			proceso.addElement(c.getString(4).toString());
			
		}
		lv.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int posicion, long id){
				seleccionado.setText("Has seleccinado: " + recetas.elementAt(posicion));
				intMostrarNuevaReceta.putExtra("idUser", idUser);
				intMostrarNuevaReceta.putExtra("idReceta", ids.elementAt(posicion));
				intMostrarNuevaReceta.putExtra("rNombre", recetas.elementAt(posicion));
				intMostrarNuevaReceta.putExtra("rIngredientes",ingrediente.elementAt(posicion) );
				intMostrarNuevaReceta.putExtra("rProcedimiento",proceso.elementAt(posicion));
				startActivity(intMostrarNuevaReceta);

			}
		});
	}
 
	public Cursor mostrarRecetas(long iuser){
		BD  db = new BD (this);
		db.open();
	    return db.mostrarRecetasUsuario(idUser);
	}
	
	
	 public void error(String e){
		 Toast.makeText(getApplicationContext(), e, Toast.LENGTH_SHORT).show();
	 }
	// Menu
			 @Override
			 public boolean onCreateOptionsMenu(Menu menu) { 
			    	super.onCreateOptionsMenu(menu);
			    	MenuInflater inflater = getMenuInflater(); 
			    	inflater.inflate(R.layout.menuprin, menu);
			    	return true;
			    }
			 public boolean onOptionsItemSelected(MenuItem item) { 	
			    	if ((item.getItemId())== R.id.about){
			    		showDialog(MENU_ABOUT);
			    	    return true;
			    	}else if ((item.getItemId())== R.id.desconectar){
			    		final Intent intLogin = new Intent(this, Recetario.class);
			    		startActivity(intLogin);
			    		return true;
			    	}
			    	else  
			    	return false;
			    }
			     
			    protected Dialog onCreateDialog(int id) { 
			    	Dialog dialog = null;
			    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
			    	if (id == MENU_ABOUT){
			    		Context context = getApplicationContext(); 
			    		LayoutInflater inflater = (LayoutInflater) 
							context.getSystemService(LAYOUT_INFLATER_SERVICE); 
			    		View layout = inflater.inflate(R.layout.about, null); 
			    		builder.setView(layout); 
			    		builder.setPositiveButton("OK", null); 
			    		dialog = builder.create();}
			    	return dialog; 
			    }
	
}
