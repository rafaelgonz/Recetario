package com.cristorey.androidchefs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
  
public class BDInsertarUsuario extends Activity{
	EditText tUsuario, tPassword, tNombre;

	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrar);
        
        tUsuario = (EditText) findViewById(R.id.regUser);
        tPassword = (EditText) findViewById(R.id.regPass);
        

        final Button botonAdd= (Button) findViewById(R.id.botonRegistrarNew);

        botonAdd.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {
        		
        		String usuario =  tUsuario.getText().toString();
        		String password = tPassword.getText().toString();
        		String nombre = tUsuario.getText().toString();
        		addUserToBD(usuario, password, nombre);	
        	}
        });   
	}
	
	public void BotonVolver(View view){
    	setContentView(R.layout.activity_recetario);
	}
	
	public void addUserToBD (String usuario, String password, String nombre){
		if ((usuario.length()!=0) && (password.length()!=0) && (nombre.length()!=0) ){ 
			 BD  db = new BD (this);
			 db.open();
			 if (db.insertarUsuario(usuario, password, nombre)){
				 Toast.makeText (this,"Usuario registrado correctamente",Toast.LENGTH_SHORT).show();
				 db.close();
				 final Intent intLogin = new Intent(BDInsertarUsuario.this, Recetario.class);
		    		startActivity(intLogin);
			 }
			 else {
				 Toast.makeText (this,"Error al registrar. \nUsuario en uso",Toast.LENGTH_SHORT).show();
				 db.close();
			 }
		     tUsuario.setText("");
		     tPassword.setText("");
			}
			else Toast.makeText (this,"Todos los campos son obligatorios",Toast.LENGTH_SHORT).show();
	}
}

