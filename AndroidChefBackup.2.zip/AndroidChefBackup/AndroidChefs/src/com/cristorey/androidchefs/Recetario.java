package com.cristorey.androidchefs;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Recetario extends Activity {
	public Usuario userLogin = new Usuario();
	public final int MENU_ABOUT = 1;
	boolean logOK = false;
	
	EditText lUser, lPassword;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recetario);
        
        final Button botonConectar= (Button) findViewById(R.id.botonEntrar);
        final Intent intPrincipal = new Intent(Recetario.this, Principal.class);
        
        botonConectar.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {
        		try{
        			lUser = (EditText) findViewById(R.id.Tuser);
        			lPassword = (EditText) findViewById(R.id.Tpass);
        			String usuario =  lUser.getText().toString();
            		String password = lPassword.getText().toString();
        			logOK = comprobarUsuario(usuario, password);

        			
        		}catch(Exception e){
        			
        		}
        		if (logOK == true){
        			intPrincipal.putExtra("idUser", userLogin.getIDUser());
        	        intPrincipal.putExtra("log_OK", logOK);
        			startActivity(intPrincipal);
        		}
        		else{
        			errorConexion();
        		}
        	}
        });   
        
        
        
        
        final Button addUser = (Button) findViewById(R.id.botonRegistrar);
        final Intent intAddUser = new Intent(Recetario.this, BDInsertarUsuario.class);
        
        addUser.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {
             		startActivity(intAddUser);
        }
        });
         
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) { 
    	super.onCreateOptionsMenu(menu);
    	MenuInflater inflater = getMenuInflater(); 
    	inflater.inflate(R.layout.menu, menu);
    	return true;
    }
    
    public boolean comprobarUsuario(String usuario, String pass){
    	BD  db = new BD (this);
		db.open();
		Cursor cursor=db.compruebaUSUARIO(usuario, pass);
		userLogin.igualar(db.capturarUsuario(cursor));
		int numElementos=cursor.getCount();
		db.close();
		if (numElementos == 1){
			return true;
		}
		else
			return false;
		 	
		
    }
    
 
    
    public void errorConexion(){
    	Toast.makeText (this,"Login incorrecto \n*Usuario/Contase�a no v�lido",Toast.LENGTH_SHORT).show();
    }
    
    public void mostrarError(String error){
    	Toast.makeText (this,"Error: "+ error,Toast.LENGTH_LONG).show();
    }
    public void botonRegistrar(View view){
    	final Intent intentAddUser = new Intent(Recetario.this, BDInsertarUsuario.class);
    	startActivity(intentAddUser);
    }
    

    public boolean onOptionsItemSelected(MenuItem item) { 	
    	if ((item.getItemId())== R.id.about){
    		showDialog(MENU_ABOUT);
    	    return true;
    	}	
    	else  
    	return false;
    }
    
    protected Dialog onCreateDialog(int id) { 
    	Dialog dialog = null;
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	if (id == MENU_ABOUT){
    		Context context = getApplicationContext(); 
    		LayoutInflater inflater = (LayoutInflater) 
				context.getSystemService(LAYOUT_INFLATER_SERVICE); 
    		View layout = inflater.inflate(R.layout.about, null); 
    		builder.setView(layout); 
    		builder.setPositiveButton("OK", null); 
    		dialog = builder.create();}
    	return dialog; 
    }
}
