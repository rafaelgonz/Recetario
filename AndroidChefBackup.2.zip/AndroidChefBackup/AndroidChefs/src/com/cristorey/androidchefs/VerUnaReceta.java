package com.cristorey.androidchefs;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.util.Vector;

 
public class VerUnaReceta extends Activity {

	Bundle id_user, id_receta, r_Nombre, r_Ingredientes, r_Procedimiento;
	long idUser, idReceta;
	String rNombre, rIngredientes, rProcedimiento;
	Receta r;
	public final int MENU_ABOUT = 1;
	public final int MENU_DESCONECTAR = 2;
	@Override
	public void onCreate(Bundle savedInstaceState){
		super.onCreate(savedInstaceState);
		setContentView(R.layout.mostrarreceta);
		
		id_user = this.getIntent().getExtras();
		idUser = id_user.getLong("idUser");
		id_receta = this.getIntent().getExtras();
		idReceta = id_receta.getLong("idReceta");
		r_Nombre = this.getIntent().getExtras();
		rNombre= id_receta.getString("rNombre");
		r_Ingredientes = this.getIntent().getExtras();
		rIngredientes= id_receta.getString("rIngredientes");
		r_Procedimiento = this.getIntent().getExtras();
		rProcedimiento= id_receta.getString("rProcedimiento");
		
		TextView nombreReceta = (TextView) findViewById(R.id.ltextoNombreReceta);
		TextView ingredientesReceta = (TextView) findViewById(R.id.lTextoIngredientes);
		TextView procedimientoReceta = (TextView) findViewById(R.id.ltextoProcedimiento);
		r = new Receta(idUser, rNombre, rIngredientes, rProcedimiento);
		nombreReceta.setText(r.getNombreRecete());
		ingredientesReceta.setText(r.getIngredientes());
		procedimientoReceta.setText(r.getPreparacion());	
	}
 
	public Receta consultarUnaReceta(long id){
		Receta una_receta;
		
		BD  db = new BD (this);
		db.open();
		una_receta = db.devuelveReceta(id);
		db.close();
		return una_receta;
	}
	
	public Cursor mostrarRecetas(long iuser){
		BD  db = new BD (this);
		db.open();
	    return db.mostrarRecetasUsuario(idUser);
	}
	
	
	 public void error(String e){
		 Toast.makeText(getApplicationContext(), e, Toast.LENGTH_SHORT).show();
	 }
	
	// Menu
		 @Override
		 public boolean onCreateOptionsMenu(Menu menu) { 
		    	super.onCreateOptionsMenu(menu);
		    	MenuInflater inflater = getMenuInflater(); 
		    	inflater.inflate(R.layout.menuenreceta, menu);
		    	return true;
		    }
		 public boolean onOptionsItemSelected(MenuItem item) { 	
		    	if ((item.getItemId())== R.id.about){
		    		showDialog(MENU_ABOUT);
		    	    return true;
		    	}else if ((item.getItemId())== R.id.desconectar){
		    		final Intent intLogin = new Intent(this, Recetario.class);
		    		startActivity(intLogin);
		    		return true;
		    	}else if ((item.getItemId())== R.id.editarRecetilla){
		    		final Intent intModReceta = new Intent(this, EditarReceta.class);
			        intModReceta.putExtra("UserLogin", idUser);
			        intModReceta.putExtra("IDreceta", idReceta);
			        intModReceta.putExtra("rNombre", rNombre);
			        intModReceta.putExtra("rIngredientes", rIngredientes);
			        intModReceta.putExtra("rProcedimiento", rProcedimiento);
			        
			        startActivity(intModReceta);
			        return true;
		    	}else if ((item.getItemId())== R.id.BorrarRecetilla){
		    		borrarReceta();
		    		return true;
		    	}
		    	else  
		    	return false;
		    }
		 
		 public void borrarReceta(){
				AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
				dialogo.setTitle("Borrando receta");
				dialogo.setIcon(R.drawable.ic_launcher);
				dialogo.setMessage("�Quiere borrar esa receta?");
				dialogo.setPositiveButton("Si", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int wich)
					{
						Toast.makeText(getApplicationContext(), "Borrando...", Toast.LENGTH_SHORT).show();
						borrarReceta(idReceta);
					}
				});
				dialogo.setNegativeButton("No", null);
				dialogo.create();
				dialogo.show();
				
			}
		 
		 
		 
		 public void borrarReceta (long idR){
				
			 BD  db = new BD (this);
			 db.open();
		     if (db.borrarUnaReceta(idR)){
		    	 Toast.makeText(getApplicationContext(), "Receta borrada correctamente.", Toast.LENGTH_SHORT).show();
		     		db.close();
		     		Intent intPrincipal = new Intent(this, Principal.class);
	        		intPrincipal.putExtra("idUser", idUser);
	    	        intPrincipal.putExtra("log_OK", true);
	    			startActivity(intPrincipal);
		     }else
		    	 Toast.makeText(getApplicationContext(), "Error al borrar la receta", Toast.LENGTH_SHORT).show();
		 }
		
		    
		    protected Dialog onCreateDialog(int id) { 
		    	Dialog dialog = null;
		    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
		    	if (id == MENU_ABOUT){
		    		Context context = getApplicationContext(); 
		    		LayoutInflater inflater = (LayoutInflater) 
						context.getSystemService(LAYOUT_INFLATER_SERVICE); 
		    		View layout = inflater.inflate(R.layout.about, null); 
		    		builder.setView(layout); 
		    		builder.setPositiveButton("OK", null); 
		    		dialog = builder.create();}
		    	return dialog; 
		    }
}



