package com.cristorey.androidchefs;

public class Usuario {
	private long id_user;
	private String usuario;
	private String pass_user;
	private String nombreUser;	

	public Usuario (long id_user, String usuario, String pass_user, String nombreUser){	
		this.id_user = id_user;
		this.usuario = usuario;
		this.pass_user = pass_user;
		this.nombreUser = nombreUser;
	}
	
	public Usuario(String usuario, String pass_user, String nombreUser){
		this.usuario = usuario;
		this.pass_user = pass_user;
		this.nombreUser = nombreUser;
	}
	public Usuario(){
		this.id_user = 0;
		this.usuario = null;
		this.pass_user = null;
		this.nombreUser = null;
	}
	public Usuario(Usuario u){
		this.id_user = u.id_user;
		this.usuario = u.usuario;
		this.pass_user = u.pass_user;
		this.nombreUser = u.nombreUser;
	}
	public void igualar(Usuario u){
		this.id_user = u.id_user;
		this.usuario = u.usuario;
		this.pass_user = u.pass_user;
		this.nombreUser = u.nombreUser;
	}
	 
	public void setIDUser(long id_user){ this.id_user = id_user;}
	public void setUsuario(String usuario){this.usuario = usuario;}
	public void setPassword(String pass_user){ this.pass_user = pass_user;}
	public void setNombreUsuario(String nombreUser){ this.nombreUser = nombreUser;}
	public long getIDUser(){ return this.id_user;}
	public String getUsuario(){ return this.usuario;}
	public String getPassword(){ return this.pass_user;}
	public String getNombreUsuario(){ return this.nombreUser;}
}