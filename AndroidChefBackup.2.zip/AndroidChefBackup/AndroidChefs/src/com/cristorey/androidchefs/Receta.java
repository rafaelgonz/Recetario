package com.cristorey.androidchefs;
 
public class Receta {
	private long id_receta;
	private long id_user;
	private String nombre_receta;
	private String ingredientes;
	private String preparacion;
	
	public Receta(long id_receta, long id_user, String nombre_receta, String ingredientes, String preparacion){
		this.id_receta = id_receta;
		this.id_user = id_user;
		this.nombre_receta = nombre_receta;
		this.ingredientes = ingredientes;
		this.preparacion = preparacion;
	}
	public Receta(long id_user, String nombre_receta, String ingredientes, String preparacion){
		this.id_user = id_user;
		this.nombre_receta = nombre_receta;
		this.ingredientes = ingredientes;
		this.preparacion = preparacion;
	}
	public Receta(){
		this.id_receta = 0;
		this.id_user = 0;
		this.nombre_receta = null;
		this.ingredientes = null;
		this.preparacion = null;
	}
	
	public Receta (Receta r){
		this.id_receta = r.id_receta;
		this.id_user = r.id_user;
		this.nombre_receta = r.nombre_receta;
		this.ingredientes = r.ingredientes;
		this.preparacion = r.preparacion;
	}
	
	public void setIDreceta(long id_receta){this.id_receta = id_receta;}
	public void setIDuser(long id_user){this.id_user = id_user;}
	public void setNombreReceta(String nombre_receta){this.nombre_receta = nombre_receta;}
	public void setIngredientes(String ingredientes){this.ingredientes = ingredientes;}
	public void setPreparacion(String preparacion){this.preparacion = preparacion;}
	public long getIDrecete(){return this.id_receta;}
	public long getIDusuario(){return this.id_user;}
	public String getNombreRecete(){return this.nombre_receta;}
	public String getIngredientes(){return this.ingredientes;}
	public String getPreparacion(){return this.preparacion;}
}
