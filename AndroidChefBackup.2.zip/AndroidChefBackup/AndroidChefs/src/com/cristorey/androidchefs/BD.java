package com.cristorey.androidchefs;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class BD {
	
	public static final String KEY_UserID = "userID";
	public static final String KEY_USUARIO = "usuario";
	public static final String KEY_PASS = "password";
	public static final String KEY_uNOMBRE = "uNombre";
	public static final String KEY_RecetaID = "_id";
	public static final String KEY_rNOMBRE = "recetaNombre";
	public static final String KEY_rINGREDIENTES = "recetaINGREDIENTES";
	public static final String KEY_rPREPARACION = "recetaPreparacion"; 

	private static final String TAG = "BD";
	
	private static final String DATABASE_NAME = "AdroidChef";
	private static final String TABLE1_NAME = "usuarios";
	private static final String TABLE2_NAME = "recetas";
	private static final int DATABASE_VERSION = 1;
	
	private static final String DATABASE_USUARIOS_CREATE = 
			"create table "+TABLE1_NAME+
			"("+KEY_UserID+" integer primary key autoincrement, "
			+KEY_USUARIO+" text unique, "
			+KEY_PASS+" text not null, "
			+KEY_uNOMBRE+" text not null);"; 
	private static final String DATABASE_RECETAS_CREATE =		
			"create table "+TABLE2_NAME+
			"("+KEY_RecetaID+" integer primary key autoincrement, "
			+KEY_UserID+" integer not null, "
			+KEY_rNOMBRE+" text not null, "
			+KEY_rINGREDIENTES+" text not null, "
			+KEY_rPREPARACION+" text not null);";
	
	private final Context context;
	
	private BaseDatosHelper BDHelper;
	private SQLiteDatabase bsSql;
	private String[] todasColumnasUsuario =new String[] {KEY_UserID, KEY_USUARIO, KEY_PASS, KEY_uNOMBRE};
	private String[] todasColumnasRecetas =new String[] {KEY_RecetaID, KEY_UserID, KEY_rNOMBRE, KEY_rINGREDIENTES, KEY_rPREPARACION};
	
	public BD(Context c){
		this.context = c;
		BDHelper = new BaseDatosHelper(c);
	}
	
	public BD open() throws SQLException{
		bsSql = BDHelper.getWritableDatabase();
		return this;
	}
	
	public void close(){
		BDHelper.close();
	}
	
	public boolean insertarUsuario(String usuario, String password, String nombre){
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_USUARIO, usuario);
		initialValues.put(KEY_PASS, password);
		initialValues.put(KEY_uNOMBRE, nombre);
		if (bsSql.insert(TABLE1_NAME, null, initialValues) > 0){
			return true;
		}
		else return false;
	}

	public long insertarReceta(long idUser, String nombre, String ingredientes, String preparacion){
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_UserID, idUser);
		initialValues.put(KEY_rNOMBRE, nombre);
		initialValues.put(KEY_rINGREDIENTES, ingredientes);
		initialValues.put(KEY_rPREPARACION, preparacion);
		return bsSql.insert(TABLE2_NAME, null, initialValues);
	}
	
	public Cursor getTodosUsuarios() {
		
		return bsSql.query(TABLE1_NAME, todasColumnasUsuario,null,null,null,null,null);
	}
	
	public Cursor getTodasRecetas() {
		return bsSql.query(TABLE2_NAME, todasColumnasRecetas,null,null,null, null, null);
	}
	
	public Cursor compruebaUSUARIO(String nombreUsuario, String pass){
		return bsSql.query(true, TABLE1_NAME, todasColumnasUsuario,KEY_USUARIO + " = '" + nombreUsuario + "' AND " + KEY_PASS + " = '" + pass+ "'",null,null,null,null,null);
	}
	
	public Cursor mostrarRecetasUsuario(long idUser){
		return bsSql.query(true,TABLE2_NAME, todasColumnasRecetas,KEY_UserID + " = " + idUser, null,null,null,null,null);
	}
	
	public boolean modificarReceta(long idPlanta, long idUser, String nombre, String ingredientes, String preparacion){
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_UserID, idUser);
		initialValues.put(KEY_rNOMBRE, nombre);
		initialValues.put(KEY_rINGREDIENTES, ingredientes);
		initialValues.put(KEY_rPREPARACION, preparacion);
		return bsSql.update(TABLE2_NAME, initialValues, KEY_RecetaID + "=" + idPlanta, null) > 0 ;
	}
	
	public Cursor consultaLAreceta(long id){
		return bsSql.query(true, TABLE2_NAME, todasColumnasRecetas, KEY_RecetaID + " = " + id, null,null,null,null,null);
	}
	
	public boolean comprobarLogin(String nombreUsuario, String pass){
		Cursor cursor=this.compruebaUSUARIO(nombreUsuario, pass);
		int numElementos=cursor.getCount();
		if (numElementos > 0){
			return true;
		}
		else
			return false;
	}
	
	public Cursor compruebaReceta(long id){
		Cursor cursor=this.consultaLAreceta(id);
		if (cursor.getCount() > 0){
			return cursor;
		}else{
			return null;}
	}
	
	public Receta devuelveReceta(long id){
		Receta r = this.cursorToReceta(compruebaReceta(id)); 
		return r;
	}
	
	
	public Usuario capturarUsuario(Cursor cursor){
		cursor.moveToFirst();
		return cursorToUsuario(cursor);
	}
	
	
	public Usuario cursorToUsuario(Cursor cursor) { 
		Usuario usuario = new Usuario(); 
		usuario.setIDUser(cursor.getLong(0));
		usuario.setPassword(cursor.getString(1));
		usuario.setUsuario(cursor.getString(2));
		usuario.setNombreUsuario(cursor.getString(3));

		return usuario;
	}
	
	public Receta cursorToReceta(Cursor cursor) { 
		Receta receta = new Receta(); 
		receta.setIDreceta(cursor.getLong(0));
		receta.setIDuser(cursor.getLong(1));
		receta.setNombreReceta(cursor.getString(2));
		receta.setIngredientes(cursor.getString(3));
		receta.setPreparacion(cursor.getString(4));
		return receta;
	}
	
	public boolean borrarUnaReceta(long idReceta){
		if(bsSql.delete(TABLE2_NAME, KEY_RecetaID + "=" + idReceta, null) > 0){
			return true;
		}
		return false;
	}
	
	public boolean borrarUnUsuario(long idUser){
		if(bsSql.delete(TABLE1_NAME, KEY_UserID + "=" + idUser, null) > 0){
			return true;
		}
		return false;
	}
	
	
	//**** CLASE PRIVADA ***/	
	
		private static class BaseDatosHelper extends SQLiteOpenHelper{
			BaseDatosHelper(Context context) {
				super(context, DATABASE_NAME, null, DATABASE_VERSION);
			}
			@Override
			public void onCreate(SQLiteDatabase db)	{
				db.execSQL(DATABASE_USUARIOS_CREATE);
				db.execSQL(DATABASE_RECETAS_CREATE);
				inicializarDB(db);
			}
			@Override
			public void onUpgrade(SQLiteDatabase db, int oldVersion,int newVersion){
					Log.w(TAG, "Actualizando base de datos de la versi�n " + oldVersion
					+ " a "
					+ newVersion + ", borraremos todos los datos");
					db.execSQL("DROP TABLE IF EXISTS " + TABLE1_NAME);
					db.execSQL("DROP TABLE IF EXISTS " + TABLE2_NAME);
					onCreate(db);
			}
			
			   public void inicializarDB(SQLiteDatabase db){
				   this.insertarReceta(db, 1, "Hojaldre de lim�n", "1 l�mina de pasta de hojaldre fresca" + 
									"\n3 cucharadas de az�car" +
									"\n2 limones" +
									"\n2 yemas de huevo" +
									"\n200 g. de mantequilla" +
									"\n200 g. de az�car", "Para la masa:\n" +
									"\tDesenrollar el hojaldre, ponerlo en una bandeja, espolvorearlo con az�car y cocerlo en el horno a una temperatura fuerte.\n" +
									"\tRetirar y dejar enfriar.\n" +
									"Para la crema de lim�n:\n" +
									"\tTrabajar las yemas con el az�car, a�adir el zumo de los limones, la ralladura de los limones y la mantequilla ablandada. Cocer a fuego suave.\n" +
									"Dejar enfriar y cubrir con ella el hojaldre.\n" +
									"Listo para servir.\n");
					this.insertarReceta(db, 1, "Bizcocho de yogur", "5 huevos\n" +
							"2 yogures naturales" +
							"\n1 vaso de aceite de girasol" +
							"\n2 vasos de az�car" +
							"\n3 vasos de harina" +
							"\n1 sobre de levadura" +
							"\nRalladura de 1 lim�n" +
							"\nZumo de 1 lim�n\n" +
							"\n1 copita de an�s","Mezclar con la batidora los huevos y el az�car." +
									"\nTamizar la harina con la levadura." +
									"\nIr mezclando todos los ingredientes con la mezcla anterior." +
									"\nEnharinar un molde redondo y echar en �l la preparaci�n." +
									"\nIntroducir en el horno a una temperatura de 160�C durante media hora aproximadamente.");
			    }
			   
			   public boolean insertarUsuario(SQLiteDatabase db, String usuario, String password, String nombre){
					ContentValues initialValues = new ContentValues();
					initialValues.put(KEY_USUARIO, usuario);
					initialValues.put(KEY_PASS, password);
					initialValues.put(KEY_uNOMBRE, nombre);
					if (db.insert(TABLE1_NAME, null, initialValues) > 0){
						return true;
					}
					else return false;
				}

				public long insertarReceta(SQLiteDatabase db, long idUser, String nombre, String ingredientes, String preparacion){
					ContentValues initialValues = new ContentValues();
					initialValues.put(KEY_UserID, idUser);
					initialValues.put(KEY_rNOMBRE, nombre);
					initialValues.put(KEY_rINGREDIENTES, ingredientes);
					initialValues.put(KEY_rPREPARACION, preparacion);
					return db.insert(TABLE2_NAME, null, initialValues);
				}
			     
		}
}
