package com.cristorey.androidchefs;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class Principal extends Activity {
	public final int MENU_ABOUT = 1;
	public final int MENU_DESCONECTAR = 2;
	long idUser2;
	Bundle id_user, log_OK;
	 @Override
	    public void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
	        setContentView(R.layout.principal);
	        id_user = this.getIntent().getExtras();
	        log_OK =  this.getIntent().getExtras();
	        
	        final long idUser = id_user.getLong("idUser");
	        final boolean logOK = log_OK.getBoolean("log_OK");
	        idUser2 = idUser;
	        final Button addReceta = (Button) findViewById(R.id.AddRecetaBOTON);
	        final Intent intAddReceta = new Intent(Principal.this, BDInsertarReceta.class);
	        intAddReceta.putExtra("UserLogin", idUser);
	        final Button deleteReceta = (Button) findViewById(R.id.deleteRecetaBOTON);
	        final Intent intdeleteReceta = new Intent(Principal.this, BDBorrarReceta.class);
	        intdeleteReceta.putExtra("idUser", idUser);
	        final Button borrarUser = (Button) findViewById(R.id.BorrarUsuarioBOTON);
	        
	        final Button verRecetas = (Button) findViewById(R.id.verRecetasBOTON);
	        final Intent intVerRecetas = new Intent(Principal.this, VerTodasRecetas.class);
	        intVerRecetas.putExtra("idUser", idUser);
	        final Button verTodasRecetas = (Button) findViewById(R.id.verTODASRecetasBOTON);
	        final Intent intVerTodasRecetas = new Intent(Principal.this, VerRecetasTodosUser.class);
	        intVerTodasRecetas.putExtra("idUser", idUser);
	        addReceta.setOnClickListener(new ImageButton.OnClickListener() {
	        	public void onClick(View v) {
	        			
	             		startActivity(intAddReceta);
	        }
	        });
	        
	        
	        deleteReceta.setOnClickListener(new ImageButton.OnClickListener() {
	        	public void onClick(View v) {
	        			
	             		startActivity(intdeleteReceta);
	        }
	        });
	        
	        borrarUser.setOnClickListener(new ImageButton.OnClickListener(){
	        	public void onClick(View v) {
	        		borrarUsuario();
	        	}
	        });
	        verRecetas.setOnClickListener(new ImageButton.OnClickListener(){
	        	public void onClick(View v) {

	        		startActivity(intVerRecetas);
	        	}
	        });
	        verTodasRecetas.setOnClickListener(new ImageButton.OnClickListener(){
	        	public void onClick(View v) {

	        		startActivity(intVerTodasRecetas);
	        	}
	        });
	        
	 }
	 
	 public void error(String e){
		 Toast.makeText(getApplicationContext(), e, Toast.LENGTH_SHORT).show();
	 }
	 
	 
	 public void borrarUsuario(){
			AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
			dialogo.setTitle("Borrando usuario");
			dialogo.setIcon(R.drawable.ic_launcher);
			dialogo.setMessage("�Quiere borrar su usuario?");
			dialogo.setPositiveButton("Si", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int wich)
				{
					Toast.makeText(getApplicationContext(), "Borrando usuario...", Toast.LENGTH_SHORT).show();
					borrandoUsuario(idUser2);
				}
			});
			dialogo.setNegativeButton("No", null);
			dialogo.create();
			dialogo.show();
			
		}
	 
	 public void borrandoUsuario (long usuarioBorrar){
		try{	
		 BD  db = new BD (this);
		 db.open();
	     if (db.borrarUnUsuario(usuarioBorrar)){
	    	 Toast.makeText(getApplicationContext(), "Usuario borrado correctamente", Toast.LENGTH_SHORT).show();
	     		db.close();
	     		final Intent intLogin = new Intent(Principal.this, Recetario.class);
	    		startActivity(intLogin);
	     }else
	    	 Toast.makeText(getApplicationContext(), "Error al borrar el usuario", Toast.LENGTH_SHORT).show();
		}catch(Exception e){
			Toast.makeText(getApplicationContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
		}
	 }
	 
	 
	 // Menu
	 @Override
	 public boolean onCreateOptionsMenu(Menu menu) { 
	    	super.onCreateOptionsMenu(menu);
	    	MenuInflater inflater = getMenuInflater(); 
	    	inflater.inflate(R.layout.menuprin, menu);
	    	return true;
	    }
	 public boolean onOptionsItemSelected(MenuItem item) { 	
	    	if ((item.getItemId())== R.id.about){
	    		showDialog(MENU_ABOUT);
	    	    return true;
	    	}else if ((item.getItemId())== R.id.desconectar){
	    		final Intent intLogin = new Intent(Principal.this, Recetario.class);
	    		startActivity(intLogin);
	    		return true;
	    	}
	    	else  
	    	return false;
	    }
	    
	    protected Dialog onCreateDialog(int id) { 
	    	Dialog dialog = null;
	    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	    	if (id == MENU_ABOUT){
	    		Context context = getApplicationContext(); 
	    		LayoutInflater inflater = (LayoutInflater) 
					context.getSystemService(LAYOUT_INFLATER_SERVICE); 
	    		View layout = inflater.inflate(R.layout.about, null); 
	    		builder.setView(layout); 
	    		builder.setPositiveButton("OK", null); 
	    		dialog = builder.create();}
	    	return dialog; 
	    }
} 
