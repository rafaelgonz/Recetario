package com.cristorey.androidchefs;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class BDBorrarReceta extends Activity {
	Bundle id_user; 
	Spinner s;
	Button botonConsulta;
	long idUser;
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.eliminarreceta);
        s = (Spinner) findViewById(R.id.spinnerRBorra);
        id_user = this.getIntent().getExtras();
        botonConsulta = (Button) findViewById(R.id.rBorrarBSel);
        idUser = id_user.getLong("idUser");
        
        try{
        	mostrarRecetas(idUser);
        	botonConsulta.setOnClickListener(new ImageButton.OnClickListener() {
            	public void onClick(View v) {
            		borrarReceta();
            }
            });
        	
        }catch (Exception e){
        	mostrarError(e.getMessage());
        }

    }
	
	public void mostrarError(String error){
    	Toast.makeText (this,"Error: "+ error,Toast.LENGTH_LONG).show();
	}
	
	public void mostrarRecetas(long idUser){
		BD  db = new BD (this);
		 db.open();
	     	Cursor cursor=db.mostrarRecetasUsuario(idUser);
        	SimpleCursorAdapter adapter2 = 
       		new SimpleCursorAdapter(this,android.R.layout.simple_spinner_item,cursor,
       	    new String[] {"recetaNombre"}, new int[] {android.R.id.text1});
        	adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        	s.setAdapter(adapter2);
        	
        	int numElementos=cursor.getCount();
        	if (numElementos == 0){
        		botonConsulta.setEnabled(false);
        		s.setEnabled(true);
        		Toast.makeText(this, "Este usuario no tiene recetas", Toast.LENGTH_LONG).show();
        	}
      db.close();
	}
	public void borrarReceta(){
		AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
		dialogo.setTitle("Borrando receta");
		dialogo.setIcon(R.drawable.ic_launcher);
		dialogo.setMessage("�Quiere borrar esa receta?");
		dialogo.setPositiveButton("Si", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int wich)
			{
				Toast.makeText(getApplicationContext(), "Borrando...", Toast.LENGTH_SHORT).show();
				Cursor cursor = (Cursor) s.getSelectedItem();
				long id_receta = cursor.getLong(0);
				borrarReceta(id_receta);
			}
		});
		dialogo.setNegativeButton("No", null);
		dialogo.create();
		dialogo.show();
		
	} 
	public void borrarReceta (long idReceta){
		
		 BD  db = new BD (this);
		 db.open();
	     if (db.borrarUnaReceta(idReceta)){
	    	 Toast.makeText(getApplicationContext(), "Receta borrada correctamente.", Toast.LENGTH_SHORT).show();
	     		db.close();
	     		Intent intPrincipal = new Intent(BDBorrarReceta.this, Principal.class);
        		intPrincipal.putExtra("idUser", idUser);
    	        intPrincipal.putExtra("log_OK", true);
    			startActivity(intPrincipal);
	     }else
	    	 Toast.makeText(getApplicationContext(), "Error al borrar la receta", Toast.LENGTH_SHORT).show();
	 }
	
}
