package com.cristorey.androidchefs;
 
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class BDInsertarReceta extends Activity{
	EditText tNombreR, tIngredientesR, tProcediemiento;
	Bundle datos;
	long id_user;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insertar_receta);
        
        tNombreR = (EditText) findViewById(R.id.lrecetaNombre);
        tIngredientesR = (EditText) findViewById(R.id.lrecetaIngredientes);
        tProcediemiento = (EditText) findViewById(R.id.lrecetaProcedimiento);
        datos = this.getIntent().getExtras();
        		
        final Button botonAdd= (Button) findViewById(R.id.rInserReceta);

        botonAdd.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {
       
        		id_user = datos.getLong("UserLogin");
        		String nombre =  tNombreR.getText().toString();
        		String ingredientes = tIngredientesR.getText().toString();
        		String procedimiento = tProcediemiento.getText().toString();
        		addRecetaToBD(id_user, nombre, ingredientes, procedimiento);	
        	}
        });   
	}
	
	
	public void addRecetaToBD (long id_user, String nombre, String ingredientes, String procedimiento){
		if ((nombre.length()!=0) && (ingredientes.length()!=0) && (procedimiento.length()!=0) ){ 
			 try{
			 BD  db = new BD (this);
			 db.open();
		     db.insertarReceta(id_user, nombre, ingredientes, procedimiento);
		     db.close();
		     Toast.makeText (this,"Receta almacenada correctamente",Toast.LENGTH_SHORT).show();
		     tNombreR.setText("");
		     tIngredientesR.setText("");
		     tProcediemiento.setText("");
		     Intent intPrincipal = new Intent(BDInsertarReceta.this, Principal.class);
     		intPrincipal.putExtra("idUser", id_user);
 	        intPrincipal.putExtra("log_OK", true);
 			startActivity(intPrincipal);
			 }catch(Exception e){
				 Toast.makeText (this,e.getMessage(),Toast.LENGTH_SHORT).show();
			 }
			 
			}
			else Toast.makeText (this,"Todos los campos son obligatorios",Toast.LENGTH_SHORT).show();
	}
}