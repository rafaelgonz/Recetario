package com.cristorey.androidchefs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
 
public class EditarReceta extends Activity {

	EditText tNombreR, tIngredientesR, tProcediemiento;
	Bundle datos, id_receta, r_Nombre, r_Ingredientes, r_Procedimiento;
	long id_user, idReceta;
	String rNombre, rIngredientes, rProcedimiento;
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.insertar_receta);

        r_Nombre = this.getIntent().getExtras();
        r_Ingredientes = this.getIntent().getExtras();
        r_Procedimiento = this.getIntent().getExtras();
        datos = this.getIntent().getExtras();
        id_receta = this.getIntent().getExtras();
        
        id_user = datos.getLong("UserLogin");
		idReceta = id_receta.getLong("IDreceta");
		rNombre = r_Nombre.getString("rNombre"); 
		rIngredientes = r_Ingredientes.getString("rIngredientes"); 
		rProcedimiento = r_Procedimiento.getString("rProcedimiento");
		
        tNombreR = (EditText) findViewById(R.id.lrecetaNombre);
        tIngredientesR = (EditText) findViewById(R.id.lrecetaIngredientes);
        tProcediemiento = (EditText) findViewById(R.id.lrecetaProcedimiento);
        tNombreR.setText(rNombre);
	    tIngredientesR.setText(rIngredientes);
	    tProcediemiento.setText(rProcedimiento);

        


        final Button botonAdd= (Button) findViewById(R.id.rInserReceta);

        botonAdd.setOnClickListener(new ImageButton.OnClickListener() {
        	public void onClick(View v) {
        		String nombre =  tNombreR.getText().toString();
        		String ingredientes = tIngredientesR.getText().toString();
        		String procedimiento = tProcediemiento.getText().toString();
        		modificarRecetaToBD(idReceta, id_user, nombre, ingredientes, procedimiento);	
        	}
        });   
	}
	
	
	public void modificarRecetaToBD (long id_receta, long id_user, String nombre, String ingredientes, String procedimiento){
		if ((nombre.length()!=0) && (ingredientes.length()!=0) && (procedimiento.length()!=0) ){ 
			 try{
			 BD  db = new BD (this);
			 db.open();
		     db.modificarReceta(id_receta, id_user, nombre, ingredientes, procedimiento);
		     db.close();
		     Toast.makeText (this,"Receta editada correctamente",Toast.LENGTH_SHORT).show();
		     tNombreR.setText("");
		     tIngredientesR.setText("");
		     tProcediemiento.setText("");
		     Intent intPrincipal = new Intent(EditarReceta.this, Principal.class);
     		intPrincipal.putExtra("idUser", id_user);
 	        intPrincipal.putExtra("log_OK", true);
 			startActivity(intPrincipal);
			 }catch(Exception e){
				 Toast.makeText (this,e.getMessage(),Toast.LENGTH_SHORT).show();
			 }
			 
			}
			else Toast.makeText (this,"Todos los campos son obligatorios",Toast.LENGTH_SHORT).show();
	}
}

