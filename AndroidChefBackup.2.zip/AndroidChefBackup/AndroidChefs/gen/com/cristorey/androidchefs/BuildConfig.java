/** Automatically generated file. DO NOT MODIFY */
package com.cristorey.androidchefs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}